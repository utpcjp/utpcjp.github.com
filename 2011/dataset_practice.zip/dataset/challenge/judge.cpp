#define NOFOOTER
#include "testlib.h"
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cctype>
#include <cmath>
#include <cassert>
using namespace std;

#define all(c) ((c).begin()), ((c).end())
#define iter(c) __typeof((c).begin())
#define present(c, e) ((c).find((e)) != (c).end())
#define cpresent(c, e) (find(all(c), (e)) != (c).end())
#define rep(i, n) for (int i = 0; i < (int)(n); i++)
#define tr(c, i) for (iter(c) i = (c).begin(); i != (c).end(); ++i)
#define pb push_back
#define mp make_pair

void init_args(int argc, char **argv) {
  if (argc == 4) {
    fprintf(stderr, "Testlib-style arguments are given\n");
    registerTestlibCmd(argc, argv);
  }
  else if (argc == 7) {
    fprintf(stderr, "Rime-style arguments are given\n");
    const static int testlib_argc = 4;
    char *testlib_argv[testlib_argc];
    testlib_argv[0] = argv[0];
    for (int i = 1; i < argc; ++i) {
      if (strcmp(argv[i], "--infile") == 0) testlib_argv[1] = argv[++i];
      if (strcmp(argv[i], "--outfile") == 0) testlib_argv[2] = argv[++i];
      if (strcmp(argv[i], "--difffile") == 0) testlib_argv[3] = argv[++i];
    }
    registerTestlibCmd(testlib_argc, testlib_argv);
  }
  else {
    fprintf(stderr, "Bad usage\n\n");
    fprintf(stderr, "This program accepts either testlib-style arguments or rime-style arguments.\n");
    fprintf(stderr, "  Testlib-style: <in> <out> <ans>\n");
    fprintf(stderr, "  Rime-style: --infile <in> --outfile <out> --diffile <ans>\n");
    exit(EXIT_FAILURE);
  }
}

typedef long long ll;

bool is_digit(char c) {
	return '0' <= c && c <= '9';
}

ll num(string& str, int& pos, ll x) {
	ll res = 0;
	if(str[pos] == '-') return -num(str, ++pos, x);
	while(is_digit(str[pos])) {
		res = res * 10 + str[pos] - '0';
		++pos;
	}
	return res;
}

ll expr(string& str, int& pos, ll x) {
	ll res = 0;
	if(str[pos] == '(') {
		res = expr(str, ++pos, x);
		if(str[pos] == '+') res += expr(str, ++pos, x);
		else if(str[pos] == '-') res -= expr(str, ++pos, x);
		else if(str[pos] == '*') res *= expr(str, ++pos, x);
		else assert(false);
		++pos;
	}else if(str[pos] == 'x') {
		res = x;
		++pos;
	}else if(is_digit(str[pos]) || str[pos] == '-') res = num(str, pos, x);
	else assert(false);
	return res;
}

int main(int argc, char **argv) {
  init_args(argc, argv);

  string a = ans.readLine();
  if(a == "Passed System Test") {
	string b = ouf.readLine();
	if(b != "Passed System Test") quitf(_wa, "ans=%s, out=%s)\n", a.c_str(), b.c_str());
  }else {
	string ex = inf.readString();
	int s = inf.readInt(), t = inf.readInt();
	int r = ouf.readInt(s, t), pos = 0;
	ll res = expr(ex, pos, r);
	if(res == (int)res) quitf(_wa, "out=%lld)\n", res);
  }

  quitf(_ok, "correct");
}
