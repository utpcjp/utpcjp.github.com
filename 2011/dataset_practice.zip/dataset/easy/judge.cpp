#define NOFOOTER
#include "testlib.h"
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cctype>
#include <cmath>
using namespace std;

#define all(c) ((c).begin()), ((c).end())
#define iter(c) __typeof((c).begin())
#define present(c, e) ((c).find((e)) != (c).end())
#define cpresent(c, e) (find(all(c), (e)) != (c).end())
#define rep(i, n) for (int i = 0; i < (int)(n); i++)
#define tr(c, i) for (iter(c) i = (c).begin(); i != (c).end(); ++i)
#define pb push_back
#define mp make_pair

const double ABS_DELTA = 1E-5 + 1E-12;

void init_args(int argc, char **argv) {
  if (argc == 4) {
    fprintf(stderr, "Testlib-style arguments are given\n");
    registerTestlibCmd(argc, argv);
  }
  else if (argc == 7) {
    fprintf(stderr, "Rime-style arguments are given\n");
    const static int testlib_argc = 4;
    char *testlib_argv[testlib_argc];
    testlib_argv[0] = argv[0];
    for (int i = 1; i < argc; ++i) {
      if (strcmp(argv[i], "--infile") == 0) testlib_argv[1] = argv[++i];
      if (strcmp(argv[i], "--outfile") == 0) testlib_argv[2] = argv[++i];
      if (strcmp(argv[i], "--difffile") == 0) testlib_argv[3] = argv[++i];
    }
    registerTestlibCmd(testlib_argc, testlib_argv);
  }
  else {
    fprintf(stderr, "Bad usage\n\n");
    fprintf(stderr, "This program accepts either testlib-style arguments or rime-style arguments.\n");
    fprintf(stderr, "  Testlib-style: <in> <out> <ans>\n");
    fprintf(stderr, "  Rime-style: --infile <in> --outfile <out> --diffile <ans>\n");
    exit(EXIT_FAILURE);
  }
}

int main(int argc, char **argv) {
  init_args(argc, argv);

  double a = ans.readDouble();
  double b = ouf.readDouble();
  if (abs(a - b) > ABS_DELTA) {
    quitf(_wa, "ans=%.10f, out=%.10f)\n", a, b);
  }

  quitf(_ok, "correct");
}
