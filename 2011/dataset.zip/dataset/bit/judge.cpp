#define NOFOOTER
#include "testlib.h"
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cctype>
#include <cmath>
#include <stdint.h>
#include <limits>
using namespace std;

#define all(c) ((c).begin()), ((c).end())
#define iter(c) __typeof((c).begin())
#define present(c, e) ((c).find((e)) != (c).end())
#define cpresent(c, e) (find(all(c), (e)) != (c).end())
#define rep(i, n) for (int i = 0; i < (int)(n); i++)
#define tr(c, i) for (iter(c) i = (c).begin(); i != (c).end(); ++i)
#define pb push_back
#define mp make_pair

////////////////////////////////////////////////////////////////////////////////

const int MAX_L = 100000;

string line;
int L;

char getat(int p) {
  if (p >= L) throw "Unexpected EOL";
  else return line[p];
}

uint32_t parse(int &p, uint32_t x) {
  if (getat(p) == 'x') {
    ++p;
    return x;
  }
  else if (getat(p) == '(') {
    ++p;
    uint32_t res;
    if (getat(p) == '~') {
      ++p;
      res = ~parse(p, x);
    } else {
      uint32_t e1 = parse(p, x);
      char op = getat(p++);
      uint32_t e2 = parse(p, x);
      switch (op) {
      case '&': res = e1 & e2; break;
      case '|': res = e1 | e2; break;
      case '^': res = e1 ^ e2; break;
      case '+': res = e1 + e2; break;
      case '-': res = e1 - e2; break;
      case '*': res = e1 * e2; break;
      default: throw "Unknown op";
      }
    }
    if (getat(p++) != ')') throw ")";
    return res;
  } else if (isdigit(getat(p))) {
    if (getat(p) == '0') {
      ++p;
      return 0;
    }
    else {
      uint64_t t = 0;
      while (isdigit(getat(p))) {
        t = t * 10 + (getat(p) - '0');
        if (t > numeric_limits<uint32_t>::max()) {
          throw "Too big constant";
        }
        ++p;
        if (p >= L) break;
      }
      return t;
    }
  } else {
    throw "Bad format";
  }
}

uint32_t compute(const string &expr, uint32_t x) {
  line = expr;
  L = expr.length();
  if (L > MAX_L) throw "Too long";
  int p = 0;
  uint32_t res = parse(p, x);
  if (p != L) throw "Extra characters after the expression";
  return res;
}

////////////////////////////////////////////////////////////////////////////////

void init_args(int argc, char **argv) {
  if (argc == 4) {
    fprintf(stderr, "Testlib-style arguments are given\n");
    registerTestlibCmd(argc, argv);
  }
  else if (argc == 7) {
    fprintf(stderr, "Rime-style arguments are given\n");
    const static int testlib_argc = 4;
    char *testlib_argv[testlib_argc];
    testlib_argv[0] = argv[0];
    for (int i = 1; i < argc; ++i) {
      if (strcmp(argv[i], "--infile") == 0) testlib_argv[1] = argv[++i];
      if (strcmp(argv[i], "--outfile") == 0) testlib_argv[2] = argv[++i];
      if (strcmp(argv[i], "--difffile") == 0) testlib_argv[3] = argv[++i];
    }
    registerTestlibCmd(testlib_argc, testlib_argv);
  }
  else {
    fprintf(stderr, "Bad usage\n\n");
    fprintf(stderr, "This program accepts either testlib-style arguments or rime-style arguments.\n");
    fprintf(stderr, "  Testlib-style: <in> <out> <ans>\n");
    fprintf(stderr, "  Rime-style: --infile <in> --outfile <out> --diffile <ans>\n");
    exit(EXIT_FAILURE);
  }
}

int main(int argc, char **argv) {
  init_args(argc, argv);
  string out = ouf.readLine();

  int N = inf.readInt();
  rep (i, N) {
    uint32_t x, y;
    x = inf.readLong();
    y = inf.readLong();

    try {
      uint32_t res = compute(out, x);
      if (res != y) {
        quitf(_wa, "f(%u) = %u (which should be %u)\n", x, res, y);
      }
    } catch (const char *msg) {
      quitf(_wa, "Format error (%s)", msg);
    }
  }

  quitf(_ok, "correct");
}
