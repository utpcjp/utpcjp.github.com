#define NOFOOTER
#include "testlib.h"
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cctype>
#include <cmath>
using namespace std;

#define all(c) ((c).begin()), ((c).end())
#define iter(c) __typeof((c).begin())
#define present(c, e) ((c).find((e)) != (c).end())
#define cpresent(c, e) (find(all(c), (e)) != (c).end())
#define rep(i, n) for (int i = 0; i < (int)(n); i++)
#define tr(c, i) for (iter(c) i = (c).begin(); i != (c).end(); ++i)
#define pb push_back
#define mp make_pair

set<pair<int, int> > usd;
vector<int> par, rnk;

int parent(int v) {
  return par[v] == v ? v : par[v] = parent(par[v]);
}

void init_args(int argc, char **argv) {
  if (argc == 4) {
    fprintf(stderr, "Testlib-style arguments are given\n");
    registerTestlibCmd(argc, argv);
  }
  else if (argc == 7) {
    fprintf(stderr, "Rime-style arguments are given\n");
    const static int testlib_argc = 4;
    char *testlib_argv[testlib_argc];
    testlib_argv[0] = argv[0];
    for (int i = 1; i < argc; ++i) {
      if (strcmp(argv[i], "--infile") == 0) testlib_argv[1] = argv[++i];
      if (strcmp(argv[i], "--outfile") == 0) testlib_argv[2] = argv[++i];
      if (strcmp(argv[i], "--difffile") == 0) testlib_argv[3] = argv[++i];
    }
    registerTestlibCmd(testlib_argc, testlib_argv);
  }
  else {
    fprintf(stderr, "Bad usage\n\n");
    fprintf(stderr, "This program accepts either testlib-style arguments or rime-style arguments.\n");
    fprintf(stderr, "  Testlib-style: <in> <out> <ans>\n");
    fprintf(stderr, "  Rime-style: --infile <in> --outfile <out> --diffile <ans>\n");
    exit(EXIT_FAILURE);
  }
}

int main(int argc, char **argv) {
  init_args(argc, argv);

  int N = inf.readInt();
  int K = inf.readInt();

  if (N < K * 2) {
    ouf.readInt(-1, -1);
  }
  else {
    par.resize(N + 1);
    rnk.resize(N + 1);

    rep (t, K) {
      for (int v = 1; v <= N; v++) par[v] = v, rnk[v] = 1;

      rep (i, N - 1) {
        int v = ouf.readInt(1, N);
        int w = ouf.readInt(1, N);

        if (v == w) quitf(_wa, "illegal edge: %d-%d", v, w);

        if (v > w) swap(v, w);
        if (usd.count(mp(v, w))) quitf(_wa, "duplicate edge: %d %d", v, w);
        usd.insert(mp(v, w));

        v = parent(v);;
        w = parent(w);
        if (v == w) quitf(_wa, "loop detected: block %d", t + 1);

        if (rnk[v] < rnk[w]) swap(v, w);
        par[w] = v;
        rnk[v] = max(rnk[v], rnk[w] + 1);
      }
    }
  }

  quitf(_ok, "correct");
}
