#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <set>
#include <cmath>
using namespace std;

////////////////////////////////////////////////////////////////////////////////

enum {ACCEPTED = 0, WRONG_ANSWER = 1};

////////////////////////////////////////////////////////////////////////////////

int judge(ifstream& correct, ifstream& output)
{
	double ax, ay, ox, oy;
	correct >> ax >> ay;
	output >> ox >> oy;
	if(!output)
		return WRONG_ANSWER;

	const double eps=2e-6;
	if( abs(ax-ox)<eps && abs(ay-oy)<eps )
		return ACCEPTED;
	return WRONG_ANSWER;
}

int main(int argc, const char* argv[])
{
	string in, out, ans;
	if(argc == 4) {
		// ./judge hoge.in hoge.out hoge.diff
		in = argv[1], out = argv[2], ans = argv[3];
	} else {
		// ./judge --infile hoge.in --difffile hoge.diff  --outfile hoge.out
		for(int i=1; i<argc; ++i) {
			if( argv[i] == string("--infile") )
				in = argv[++i];
			else if( argv[i] == string("--difffile") )
				ans = argv[++i];
			else if( argv[i] == string("--outfile") )
				out = argv[++i];
		}
	}

	ifstream correct(ans.c_str()), output(out.c_str());
	return judge(correct, output);
}
